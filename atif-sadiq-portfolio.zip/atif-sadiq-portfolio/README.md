# Atif Sadiq — Personal Portfolio Website

A static, single-page portfolio website for Atif Sadiq, BS Artificial Intelligence graduate
from The Islamia University of Bahawalpur. No backend, database, or build process required.

## Structure

```
atif-sadiq-portfolio/
│
├── index.html          Main website file (all sections: Hero, About, Education,
│                        AGRIS case study, Academic Work, Skills, Tools, How I Work,
│                        Career Direction, Contact, Footer)
├── css/
│   └── style.css        All site styling (layout, color tokens, responsive rules,
│                         scroll-reveal transitions)
├── js/
│   └── script.js        Sticky nav on scroll, mobile menu toggle, scroll-reveal
│                         animation (IntersectionObserver, respects reduced-motion)
├── assets/
│   ├── images/           Reserved for local images (e.g. profile photo,
│   │                      AGRIS project screenshots) — currently empty
│   ├── icons/             Reserved for local icon files — currently empty
│   └── fonts/             Reserved for self-hosted font files — currently empty
└── README.md
```

## External dependencies (CDN — no local files needed)

- Google Fonts: Plus Jakarta Sans, Inter
- Font Awesome 6.5.1 (icons) — via cdnjs

Both are loaded via `<link>` tags in `index.html` and require an internet connection
to render correctly. No other frameworks, libraries, or build tools are used —
this is plain HTML5, CSS3, and vanilla JavaScript.

## Adding your own assets

The hero visual and favicon are currently inline SVG (no image files needed).
The profile photo section and the AGRIS project gallery currently use placeholders
marked directly in `index.html` (search for `photo-slot` and `g-placeholder`).

To add real images:
1. Drop your files into `assets/images/` (e.g. `profile.jpg`, `agris-rover.jpg`).
2. In `index.html`, replace the relevant placeholder block with an `<img>` tag,
   e.g. `<img src="assets/images/profile.jpg" alt="Atif Sadiq">`.
3. Update the matching CSS class in `css/style.css` if you want to adjust sizing.

## Running locally

No build step is required. Simply open `index.html` in any modern browser,
or serve the folder with any static file server, e.g.:

```
npx serve .
```

## Deploying

This project is ready for any static hosting provider, including:

- GitHub Pages
- Netlify
- Vercel
- Any cPanel / shared hosting static file upload

Just upload the contents of this folder (or point your host at this repository)
— no environment variables, database, or server-side configuration needed.

## Contact

Email: atifsadiq273@gmail.com
Location: Liaquatpur, Pakistan
