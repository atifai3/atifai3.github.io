(function(){
  var header=document.getElementById('siteHeader');
  window.addEventListener('scroll',function(){
    if(window.scrollY>40){header.classList.add('scrolled');}else{header.classList.remove('scrolled');}
  });

  var burger=document.getElementById('burgerBtn');
  var closeBtn=document.getElementById('closeBtn');
  var menu=document.getElementById('mobileMenu');
  function openMenu(){menu.classList.add('open');}
  function closeMenu(){menu.classList.remove('open');}
  burger.addEventListener('click',openMenu);
  closeBtn.addEventListener('click',closeMenu);
  menu.querySelectorAll('a').forEach(function(a){a.addEventListener('click',closeMenu);});

  var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(!reduce && 'IntersectionObserver' in window){
    var targets=document.querySelectorAll('section .wrap > *, .case-block-inner, .p-step, .tl-item, .ac-cell, .tool-card');
    targets.forEach(function(el){el.classList.add('reveal');});
    var obs=new IntersectionObserver(function(entries){
      entries.forEach(function(e){
        if(e.isIntersecting){e.target.classList.add('in');obs.unobserve(e.target);}
      });
    },{threshold:0.12,rootMargin:'0px 0px -40px 0px'});
    targets.forEach(function(el){obs.observe(el);});
  }
})();
